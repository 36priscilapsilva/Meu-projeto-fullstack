const form = document.getElementById('product-form');
const productList = document.getElementById('product-list');
const API_URL = 'http://localhost:5000/api/products'; 

document.addEventListener('DOMContentLoaded', () => {
  loadProducts();
});

function loadProducts() {
  fetch(API_URL)
    .then(response => response.json())
    .then(products => {
      productList.innerHTML = ''; 
      products.forEach(product => {
        const productItem = document.createElement('li');
        productItem.innerHTML = `
          <strong>Nome:</strong> ${product.name} <br>
          <strong>Descrição:</strong> ${product.description} <br>
          <strong>Preço:</strong> R$${product.price.toFixed(2)} <br>
          <strong>Estoque:</strong> ${product.stock} unidades
        `;
        productList.appendChild(productItem);
      });
    })
    .catch(error => console.error('Erro ao carregar produtos:', error));
}

form.addEventListener('submit', (e) => {
  e.preventDefault();

  const productData = {
    name: document.getElementById('name').value,
    description: document.getElementById('description').value,
    price: parseFloat(document.getElementById('price').value),
    stock: parseInt(document.getElementById('stock').value),
  };

  fetch(API_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify(productData),
  })
  .then(response => response.json())
  .then(product => {
    alert('Produto cadastrado com sucesso!');
    loadProducts();
    form.reset(); 
  })
  .catch(error => console.error('Erro ao cadastrar produto:', error));
});
